---
language:
- en
arxiv:
- 2412.18702
- 2406.00583
pretty_name: CMDBench-NBA
task_categories:
- text2text-generation
- other
modalities:
- text
- tabular
- graph
size_categories:
- 1B<n<10B
license: cc-by-sa-4.0
---

# cmdbench-nba

CMDBench-NBA is a multimodal NBA datalake that consists of a Neo4j knowledge graph, a PostgreSQL relational database, and a MongoDB document collection. It is originally proposed in the [CMDBench](https://arxiv.org/abs/2406.00583) paper but has been updated with higher quality data (up to Feburary 2025).

Contact: yanlin@megagon.ai

## Deploying the databases

First, clone the repository with git lfs installed.

```bash
# Make sure git-lfs is installed (https://git-lfs.com)
git lfs install

git clone https://huggingface.co/datasets/megagonlabs/cmdbench-nba
```

Next, run the following commands under the root directory of the repository.

### Starting cmdbench-nba-postgres

```bash
docker run -d \
  --name cmdbench-nba-postgres \
  -e POSTGRES_DB=nba_db \
  -e POSTGRES_HOST_AUTH_METHOD=trust \
  -p 22111:5432 \
  -v "$(pwd)/postgres/nba_db.sql:/docker-entrypoint-initdb.d/nba_db.sql" \
  postgres
```

### Starting cmdbench-nba-neo4j

```bash
docker run -d \
  --name cmdbench-nba-neo4j \
  -p 22112:7687 \
  -p 22115:7474 \
  -v "$(pwd)/neo4j/nba_simplekg.json:/init/graph.json" \
  -e NEO4J_AUTH=neo4j/cmdbench \
  -e NEO4J_PLUGINS='["apoc", "graph-data-science"]' \
  megagonlabs/neo4j-with-loader:2.4
```

### Starting cmdbench-nba-mongo

```bash
docker run -d \
  --name cmdbench-nba-mongo \
  -p 22113:27017 \
  -v "$(pwd)/mongo/nba-datalake.wiki-documents.json:/init/nba-datalake.wiki-documents.json" \
  -v "$(pwd)/mongo/init-nba-mongo.sh:/docker-entrypoint-initdb.d/init-nba-mongo.sh" \
  mongo mongod --noauth
```

## Connection Info
| Database | Port | Username | Password | Data Location |
|----------|------|----------|----------|---------------|
| Postgres | 22111 | postgres | - | db=nba_db, schema=public |
| Neo4j | 22112 (bolt) / 22115 (neo4j browser) | neo4j | cmdbench | db=neo4j |
| MongoDB | 22113 | - | - | db=nba-datalake, collection=wiki-documents |


## Citation

If you use this dataset in your work, please cite the following papers:

```bibtex
@article{feng2024cypherbench,
  title={CypherBench: Towards Precise Retrieval over Full-scale Modern Knowledge Graphs in the LLM Era},
  author={Feng, Yanlin and Papicchio, Simone and Rahman, Sajjadur},
  journal={arXiv preprint arXiv:2412.18702},
  year={2024}
}
```

```bibtex
@inproceedings{feng2024cmdbench,
  title={CMDBench: A Benchmark for Coarse-to-fine Multimodal Data Discovery in Compound AI Systems},
  author={Feng, Yanlin and Rahman, Sajjadur and Feng, Aaron and Chen, Vincent and Kandogan, Eser},
  booktitle={Proceedings of the Conference on Governance, Understanding and Integration of Data for Effective and Responsible AI},
  pages={16--25},
  year={2024}
}
```

## Attribution

This dataset is built upon the following data sources:

- [Kaggle NBA DB](https://www.kaggle.com/datasets/wyattowalsh/basketball) (license: [CC-BY-SA-4.0](https://creativecommons.org/licenses/by-sa/4.0/))
- [Wikipedia](https://en.wikipedia.org/) (license: [CC-BY-SA-3.0](https://creativecommons.org/licenses/by-sa/3.0/))
- [Wikidata](https://www.wikidata.org/) (license: [CC0](https://creativecommons.org/publicdomain/zero/1.0/))


## Disclosure

Embedded in, or bundled with, this product are open source software (OSS) components, datasets and other third party components identified below. The license terms respectively governing the datasets and third-party components continue to govern those portions, and you agree to those license terms, which, when applicable, specifically limit any distribution. You may receive a copy of, distribute and/or modify any open source code for the OSS component under the terms of their respective licenses, which may be CC license and Apache 2.0 license. In the event of conflicts between Megagon Labs, Inc., license conditions and the Open Source Software license conditions, the Open Source Software conditions shall prevail with respect to the Open Source Software portions of the software. You agree not to, and are not permitted to, distribute actual datasets used with the OSS components listed below. You agree and are limited to distribute only links to datasets from known sources by listing them in the datasets overview table below. You are permitted to distribute derived datasets of data sets from known sources by including links to original dataset source in the datasets overview table below. You agree that any right to modify datasets originating from parties other than Megagon Labs, Inc. are governed by the respective third party’s license conditions. All OSS components and datasets are distributed WITHOUT ANY WARRANTY, without even implied warranty such as for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, and without any liability to or claim against any Megagon Labs, Inc. entity other than as explicitly documented in this README document. You agree to cease using any part of the provided materials if you do not agree with the terms or the lack of any warranty herein. While Megagon Labs, Inc., makes commercially reasonable efforts to ensure that citations in this document are complete and accurate, errors may occur. If you see any error or omission, please help us improve this document by sending information to contact_oss@megagon.ai.